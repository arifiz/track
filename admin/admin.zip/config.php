<?php 
mysql_connect("localhost","root","admin");
mysql_select_db("malasngoding_kios");
?>