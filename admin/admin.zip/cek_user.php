<script language="JavaScript">
			alert('Script ini telah dilakukan uji lisensi! JANGAN PLAGIAT');
			document.location='admin/index.php';
</script>